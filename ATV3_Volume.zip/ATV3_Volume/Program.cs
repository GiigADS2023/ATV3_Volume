﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Volume
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o raio:");
            float valueRaio = float.Parse(Console.ReadLine());
            Console.WriteLine("Digite a altura:");
            float valueAltura = float.Parse(Console.ReadLine());

            float value = Volume(valueRaio, valueAltura);

            Console.WriteLine("O volume do galão: " + value);
            Console.ReadLine();
        }

        static float Volume(float raio, float altura)
        {
            const float PI = 3.1415f;
            float resultadoFinal = PI * raio * raio * altura;
            return resultadoFinal;
        }
    }
}
